package Activities.MenuPrincipal;

import android.app.Activity;
import android.widget.ImageButton;

import com.example.iafandroid.R;

public class MenuPrincipalVista {
    public Activity getActividad() {
        return actividad;
    }

    private Activity actividad;
    private MenuPrincipalModelo modelo;
    private MenuPrincipalControl control;
    private ImageButton btnLiquidaciones;

    MenuPrincipalVista(Activity actividad, MenuPrincipalModelo modelo){
        this.actividad=actividad;
        this.modelo=modelo;
        setearReferenciasControles();
    }

    private void setearReferenciasControles(){
        this.btnLiquidaciones = this.actividad.findViewById(R.id.btnLiquidaciones);
    }

    public void setControl(MenuPrincipalControl control) {
        this.control = control;
        this.setControladores();
    }

    private void setControladores(){
        this.btnLiquidaciones.setOnClickListener(this.control);
    }


}
