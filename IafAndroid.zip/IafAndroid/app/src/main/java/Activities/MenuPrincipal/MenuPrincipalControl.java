package Activities.MenuPrincipal;

import android.content.Intent;
import android.util.Log;
import android.view.View;

import com.example.iafandroid.R;

import Activities.LogIn.LogInActivity;
import Activities.VisualizarLiquidaciones.ViasualizarLiquidacionesActivity;

public class MenuPrincipalControl implements View.OnClickListener {
    private MenuPrincipalVista vista;
    private MenuPrincipalModelo modelo;

    public MenuPrincipalControl(MenuPrincipalModelo modelo, MenuPrincipalVista vista) {
        this.modelo=modelo;
        this.vista=vista;
        this.vista.setControl(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()== R.id.btnLiquidaciones){
            Log.d("MenuPrincipalControl","Click en btnLiquidaciones");

            MenuPrincipalActivity a = (MenuPrincipalActivity) vista.getActividad();
            Intent i = new Intent(vista.getActividad(), ViasualizarLiquidacionesActivity.class);
            i.putExtra("id",a.getLogIn().getId());
            i.putExtra("nombre",a.getLogIn().getNombre());
            i.putExtra("apellido",a.getLogIn().getApellido());

            a.iniciarActividad(i);
        }
    }
}
