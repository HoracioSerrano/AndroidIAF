package Activities.MenuPrincipal;

public class MenuPrincipalModelo {
}
