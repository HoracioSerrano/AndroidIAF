package Activities.MenuPrincipal;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.iafandroid.R;

import Utilitarios.dtoLogIn;

public class MenuPrincipalActivity extends AppCompatActivity {
    public dtoLogIn getLogIn() {
        return LogIn;
    }

    dtoLogIn LogIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
        MenuPrincipalModelo modelo = new MenuPrincipalModelo();
        MenuPrincipalVista vista = new MenuPrincipalVista(this,modelo);
        MenuPrincipalControl control = new MenuPrincipalControl(modelo,vista);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        LogIn=new dtoLogIn();
        LogIn.setId(extras.getString("id"));
        LogIn.setNombre(extras.getString("nombre"));
        LogIn.setApellido(extras.getString("apellido"));

        Log.d("ResultadoHttp","Json: " + LogIn.toString());
    }

    public void iniciarActividad(Intent i){
        startActivity(i);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.opt1){
            finishAffinity();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
