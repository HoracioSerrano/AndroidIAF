package Activities.VisualizarLiquidaciones;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.iafandroid.R;

public class LiquidacionViewHolder extends RecyclerView.ViewHolder  implements
        View.OnClickListener {
    TextView id;
    TextView nombre;
    LiquidacionClick liquidacionClick;
    private int position;



    public LiquidacionViewHolder(@NonNull View itemView, LiquidacionClick liquidacionClick) {
        super(itemView);
         id = itemView.findViewById(R.id.tvIdLiquidacion);
         nombre = itemView.findViewById(R.id.tvNombreLiquidacion);
         itemView.setOnClickListener(this);
         this.liquidacionClick=liquidacionClick;
    }

    @Override
    public void onClick(View view) {
        liquidacionClick.onItemClick(position);
    }

    public void setPosition(int position)
    {
        this.position = position;
    }

}
