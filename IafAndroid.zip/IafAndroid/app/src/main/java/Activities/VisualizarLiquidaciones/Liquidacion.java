package Activities.VisualizarLiquidaciones;

public class Liquidacion {
    private String idLiquidacion;
    private String nombreLiquidacion;

    public Liquidacion(String idLiquidacion, String nombreLiquidacion) {
        this.idLiquidacion = idLiquidacion;
        this.nombreLiquidacion = nombreLiquidacion;
    }

    public String getIdLiquidacion() {
        return idLiquidacion;
    }

    public void setIdLiquidacion(String idLiquidacion) {
        this.idLiquidacion = idLiquidacion;
    }

    public String getNombreLiquidacion() {
        return nombreLiquidacion;
    }

    public void setNombreLiquidacion(String nombreLiquidacion) {
        this.nombreLiquidacion = nombreLiquidacion;
    }

    @Override
    public String toString() {
        return "Liquidacion{" +
                "id='" + idLiquidacion + '\'' +
                ", descripcion='" + nombreLiquidacion + '\'' +
                '}';
    }
}
