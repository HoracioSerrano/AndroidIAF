package Activities.VisualizarLiquidaciones;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.iafandroid.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import Activities.LogIn.LogInActivity;
import Activities.MenuPrincipal.MenuPrincipalActivity;
import Utilitarios.HiloPost;
import Utilitarios.dtoLogIn;

public class ViasualizarLiquidacionesActivity extends AppCompatActivity  implements LiquidacionClick, Handler.Callback {
    public dtoLogIn getLogIn() {
        return LogIn;
    }

    dtoLogIn LogIn;

    List<Liquidacion>  liquidaciones;
    List<Concepto> conceptos;
    ConceptoAdapter adaptadorConceptos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_liquidaciones);
        //liquidaciones = generarLiquidaciones();
        consultaLiquidaciones();
/*
        LiquidacionAdapter LA = new LiquidacionAdapter(liquidaciones,this);
        RecyclerView LRV = super.findViewById(R.id.recyclerViewLiquidaciones);
        LRV.setAdapter(LA);
        LinearLayoutManager LLM = new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
        LRV.setLayoutManager(LLM);

        conceptos = generarConceptosPorLiquidacion(liquidaciones.get(0));
        adaptadorConceptos = new ConceptoAdapter(conceptos);
        RecyclerView CRV = super.findViewById(R.id.recyclerViewConceptos);
        CRV.setAdapter(adaptadorConceptos);
        LinearLayoutManager CLLM = new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
        CRV.setLayoutManager(CLLM);
*/



    }
/*
    private List<Liquidacion> generarLiquidaciones() {
        List<Liquidacion> liquidaciones = new ArrayList<Liquidacion>();
        liquidaciones.add(new Liquidacion("5", "Mayo 2024"));
        liquidaciones.add(new Liquidacion("4", "Abril 2024"));
        liquidaciones.add(new Liquidacion("3", "Marzo 2024"));
        liquidaciones.add(new Liquidacion("2", "Febrero 2024"));
        liquidaciones.add(new Liquidacion("1", "Enero 2024"));
        return liquidaciones;
    }

    private List<Concepto> generarConceptosPorLiquidacion(Liquidacion liquidacion) {
        List<Concepto> conceptos = new ArrayList<>();

        switch (liquidacion.getIdLiquidacion()) {
            case "1": // Enero
                conceptos.add(new Concepto("1", "Salario Base", "$1200"));
                conceptos.add(new Concepto("2", "Descuentos", "$-200"));
                conceptos.add(new Concepto("3", "Horas Extra", "$300"));
                conceptos.add(new Concepto("4", "Comisiones", "$150"));
                conceptos.add(new Concepto("5", "Bonificaciones", "$100"));
                conceptos.add(new Concepto("6", "Aguinaldo", "$50"));
                conceptos.add(new Concepto("7", "Otros", "$75"));
                break;
            case "2": // Febrero
                conceptos.add(new Concepto("1", "Salario Base", "$1100"));
                conceptos.add(new Concepto("2", "Descuentos", "$-150"));
                conceptos.add(new Concepto("3", "Horas Extra", "$250"));
                conceptos.add(new Concepto("4", "Comisiones", "$100"));
                conceptos.add(new Concepto("5", "Bonificaciones", "$200"));
                conceptos.add(new Concepto("6", "Aguinaldo", "$50"));
                conceptos.add(new Concepto("7", "Otros", "$30"));
                break;
            case "3": // Marzo
                conceptos.add(new Concepto("1", "Salario Base", "$1150"));
                conceptos.add(new Concepto("2", "Descuentos", "$-180"));
                conceptos.add(new Concepto("3", "Horas Extra", "$220"));
                conceptos.add(new Concepto("4", "Comisiones", "$120"));
                conceptos.add(new Concepto("5", "Bonificaciones", "$90"));
                conceptos.add(new Concepto("6", "Aguinaldo", "$50"));
                conceptos.add(new Concepto("7", "Otros", "$40"));
                break;
            case "4": // Abril
                conceptos.add(new Concepto("1", "Salario Base", "$1300"));
                conceptos.add(new Concepto("2", "Descuentos", "$-250"));
                conceptos.add(new Concepto("3", "Horas Extra", "$280"));
                conceptos.add(new Concepto("4", "Comisiones", "$170"));
                conceptos.add(new Concepto("5", "Bonificaciones", "$130"));
                conceptos.add(new Concepto("6", "Aguinaldo", "$50"));
                conceptos.add(new Concepto("7", "Otros", "$60"));
                break;
            case "5": // Mayo
                conceptos.add(new Concepto("1", "Salario Base", "$1400"));
                conceptos.add(new Concepto("2", "Descuentos", "$-200"));
                conceptos.add(new Concepto("3", "Horas Extra", "$320"));
                conceptos.add(new Concepto("4", "Comisiones", "$190"));
                conceptos.add(new Concepto("5", "Bonificaciones", "$140"));
                conceptos.add(new Concepto("6", "Aguinaldo", "$50"));
                conceptos.add(new Concepto("7", "Otros", "$80"));
                break;
            default:
                // Si la liquidación no coincide con ninguna
                break;
        }

        return conceptos;
    }
*/
    @Override
    public void onItemClick(int position) {
        Log.d("Liquidaciones", "Posicion: " + String.valueOf(position));
        //adaptadorConceptos.setConceptos(generarConceptosPorLiquidacion(liquidaciones.get(position)));
        consultaConceptos(liquidaciones.get(position));
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }


    public void consultaLiquidaciones(){
        Handler handler = new Handler(this);
        Uri.Builder params = new Uri.Builder();
        params.appendQueryParameter("id", "1");
        HiloPost hilo = new HiloPost(handler, "http://10.0.2.2:5069/Liquidaciones", params);
        hilo.setValorArg(0);
        hilo.start();
    }

    public void consultaConceptosInicial(Liquidacion liq){
        Handler handler = new Handler(this);
        Uri.Builder params = new Uri.Builder();
        params.appendQueryParameter("idLiquidacion", liq.getIdLiquidacion());
        HiloPost hilo = new HiloPost(handler, "http://10.0.2.2:5069/ConceptosLiquidacion", params);
        hilo.setValorArg(1);
        hilo.start();
    }

    public void consultaConceptos(Liquidacion liq){
        Handler handler = new Handler(this);
        Uri.Builder params = new Uri.Builder();
        params.appendQueryParameter("idLiquidacion", liq.getIdLiquidacion());
        HiloPost hilo = new HiloPost(handler, "http://10.0.2.2:5069/ConceptosLiquidacion", params);
        hilo.setValorArg(2);
        hilo.start();
    }



    @Override
    public boolean handleMessage(@NonNull Message message) {
        String respuesta = (String)message.obj;
        if (!respuesta.equals("error")) {
            if(message.arg1==0){
                deserializarLiquidaciones(respuesta);
            }
            if(message.arg1==1){
                 conceptos = deserializarConceptos(respuesta);
                //Log.d("ResultadoHttp","conceptos: " + conceptos.get(0).getImporteConcepto());
                adaptadorConceptos = new ConceptoAdapter(conceptos);
                RecyclerView CRV = super.findViewById(R.id.recyclerViewConceptos);
                CRV.setAdapter(adaptadorConceptos);
                LinearLayoutManager CLLM = new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
                CRV.setLayoutManager(CLLM);
            }
            if(message.arg1==2){
                conceptos = deserializarConceptos(respuesta);
                adaptadorConceptos.setConceptos(conceptos);
            }


        }
        return true;
    }


    public void deserializarLiquidaciones(String respuesta){
        // Crear un JSONArray a partir del JSON String
        try {
            Log.d("ResultadoHttp","Json liquidaciones: " + respuesta);
            JSONArray jsonArray = new JSONArray(respuesta);
            List<Liquidacion> liquidaciones = new ArrayList<>();

            // Iterar a través del JSONArray y extraer los datos
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String idLiquidacion = jsonObject.getString("idLiquidacion");
                String nombreLiquidacion = jsonObject.getString("nombreLiquidacion");

                // Crear un objeto Liquidacion y agregarlo a la lista
                liquidaciones.add(new Liquidacion(idLiquidacion, nombreLiquidacion));
            }
            this.liquidaciones=liquidaciones;

            LiquidacionAdapter LA = new LiquidacionAdapter(liquidaciones,this);
            RecyclerView LRV = super.findViewById(R.id.recyclerViewLiquidaciones);
            LRV.setAdapter(LA);
            LinearLayoutManager LLM = new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
            LRV.setLayoutManager(LLM);

            consultaConceptosInicial(liquidaciones.get(0));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Concepto> deserializarConceptos(String respuesta){
        // Crear un JSONArray a partir del JSON String
        try {
            Log.d("ResultadoHttp","deserializar: " + respuesta);
            JSONArray jsonArray = new JSONArray(respuesta);
            List<Concepto> conceptos = new ArrayList<>();

            // Iterar a través del JSONArray y extraer los datos
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String idConcepto = jsonObject.getString("idConcepto");
                String nombreConcepto = jsonObject.getString("nombreConcepto");
                String importeConcepto = jsonObject.getString("importeConcepto");

                // Crear un objeto Liquidacion y agregarlo a la lista
                conceptos.add(new Concepto(idConcepto, nombreConcepto,importeConcepto));
                Log.d("ResultadoHttp","conceptos: " + conceptos.get(0).getImporteConcepto());
            }
            return conceptos;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.opt1){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuvolver,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
