package Activities.VisualizarLiquidaciones;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.iafandroid.R;

import java.util.List;

public class ConceptoAdapter extends RecyclerView.Adapter<ConceptoViewHolder> {



    List<Concepto> conceptos;

    public ConceptoAdapter(List<Concepto> conceptos) {
        this.conceptos = conceptos;
    }

    @NonNull
    @Override
    public ConceptoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_concepto,parent,false);
        return new ConceptoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ConceptoViewHolder holder, int position) {
        Concepto c = this.conceptos.get(position);
        TextView id = holder.id;
        id.setText(c.getIdConcepto());
        TextView nombre = holder.nombre;
        nombre.setText(c.getNombreConcepto());
        TextView importe = holder.importe;
        importe.setText(c.getImporteConcepto());

    }

    @Override
    public int getItemCount() {
        return this.conceptos.size();
    }

    public List<Concepto> getConceptos() {
        return conceptos;
    }

    public void setConceptos(List<Concepto> conceptos) {
        this.conceptos = conceptos;
        this.notifyDataSetChanged();
    }
}
