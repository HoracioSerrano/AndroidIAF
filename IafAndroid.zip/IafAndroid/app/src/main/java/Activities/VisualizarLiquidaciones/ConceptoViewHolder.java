package Activities.VisualizarLiquidaciones;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.iafandroid.R;

public class ConceptoViewHolder extends RecyclerView.ViewHolder {
    TextView id;
    TextView nombre;
    TextView importe;
    public ConceptoViewHolder(@NonNull View itemView) {
        super(itemView);
         id = itemView.findViewById(R.id.tvIdConcepto);

         nombre = itemView.findViewById(R.id.tvNombreConcepto);

         importe = itemView.findViewById(R.id.tvImporteConcepto);
    }
}
