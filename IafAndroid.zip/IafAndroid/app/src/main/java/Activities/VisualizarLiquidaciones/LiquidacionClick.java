package Activities.VisualizarLiquidaciones;

public interface LiquidacionClick {
    void onItemClick(int position);
}
