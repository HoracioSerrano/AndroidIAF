package Activities.VisualizarLiquidaciones;

public class Concepto {
    private String idConcepto;
    private String nombreConcepto;
    private String importeConcepto;

    public Concepto(String concepto, String nombreConcepto, String importeConcepto) {
        this.idConcepto = concepto;
        this.nombreConcepto = nombreConcepto;
        this.importeConcepto = importeConcepto;
    }

    public String getIdConcepto() {
        return idConcepto;
    }

    public String getNombreConcepto() {
        return nombreConcepto;
    }

    public String getImporteConcepto() {
        return importeConcepto;
    }

    @Override
    public String toString() {
        return "Concepto{" +
                "concepto='" + idConcepto + '\'' +
                ", nombre='" + nombreConcepto + '\'' +
                ", importe='" + importeConcepto + '\'' +
                '}';
    }
}