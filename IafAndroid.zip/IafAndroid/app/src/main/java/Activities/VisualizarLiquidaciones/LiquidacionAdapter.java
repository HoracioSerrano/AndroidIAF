package Activities.VisualizarLiquidaciones;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.iafandroid.R;

import java.util.List;

public class LiquidacionAdapter extends RecyclerView.Adapter<LiquidacionViewHolder> {

    private List<Liquidacion> liquidaciones;
    private LiquidacionClick liquidacionClick;


    public LiquidacionAdapter(List<Liquidacion> liquidaciones, LiquidacionClick lc) {
        this.liquidaciones = liquidaciones;
        this.liquidacionClick = lc;
    }

    @NonNull
    @Override
    public LiquidacionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_liquidacion,parent,false);
        return new LiquidacionViewHolder(v,liquidacionClick);
    }

    @Override
    public void onBindViewHolder(@NonNull LiquidacionViewHolder holder, int position) {
        Liquidacion l = this.liquidaciones.get(position);
        TextView id = holder.id;
        id.setText(l.getIdLiquidacion());
        TextView nombre = holder.nombre;
        nombre.setText(l.getNombreLiquidacion());
        holder.setPosition(position);

    }

    @Override
    public int getItemCount() {
        return liquidaciones.size();
    }
}
