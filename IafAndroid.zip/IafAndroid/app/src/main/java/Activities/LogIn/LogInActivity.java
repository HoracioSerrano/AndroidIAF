package Activities.LogIn;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.iafandroid.R;

import Activities.MenuPrincipal.MenuPrincipalActivity;
import Utilitarios.HiloConsultaPost;
import Utilitarios.HiloPost;

public class LogInActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);
        LogInModelo modelo = new LogInModelo("","","");
        LogInVista vista = new LogInVista(this,modelo);
        LogInControl control = new LogInControl(modelo,vista);


/*
        Intent i = new Intent(this, MenuPrincipalActivity.class);
        startActivity(i);*/

    }

    public void iniciarActividad(Intent i){
        startActivity(i);
    }

}
