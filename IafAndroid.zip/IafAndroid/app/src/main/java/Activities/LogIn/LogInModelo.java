package Activities.LogIn;

public class LogInModelo {
    private String Usuario;
    private String Password;
    private String MensajeError;

    public LogInModelo(String usuario, String password, String mensajeError) {
        Usuario = usuario;
        Password = password;
        MensajeError = mensajeError;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        Usuario = usuario;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getMensajeError() {
        return MensajeError;
    }

    public void setMensajeError(String mensajeError) {
        MensajeError = mensajeError;
    }

    @Override
    public String toString() {
        return "LogInModelo{" +
                "Usuario='" + Usuario + '\'' +
                ", Password='" + Password + '\'' +
                ", MensajeError='" + MensajeError + '\'' +
                '}';
    }
}
