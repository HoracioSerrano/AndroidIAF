package Activities.LogIn;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import com.example.iafandroid.R;

import org.json.JSONException;
import org.json.JSONObject;

import Activities.MenuPrincipal.MenuPrincipalActivity;
import Utilitarios.HiloPost;
import Utilitarios.dtoLogIn;

public class LogInControl implements View.OnClickListener, Handler.Callback{
    private LogInModelo modelo;
    private LogInVista vista;


    public LogInControl(LogInModelo modelo, LogInVista vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.setControl(this);
    }

    @Override
    public void onClick(View view) {
        vista.cargarDesdeVista();
        if (view.getId() == R.id.btnIngresar){
            btnIngresarClick();
        }


    }



    public void btnIngresarClick(){
        Handler handler = new Handler(this);
        Uri.Builder params = new Uri.Builder();
        params.appendQueryParameter("Usuario",modelo.getUsuario());
        params.appendQueryParameter("Password", modelo.getPassword());
        HiloPost hilo = new HiloPost(handler, "http://10.0.2.2:5069/LogIn", params);
        hilo.start();
    }



    @Override
    public boolean handleMessage(@NonNull Message message) {
        String respuesta = (String)message.obj;
        if (!respuesta.equals("error")){
            modelo.setMensajeError(respuesta);

            dtoLogIn dto = new dtoLogIn();


            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(respuesta);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            // Extraer los valores
            try {
                dto.setId(jsonObject.getString("id"));
                dto.setNombre(jsonObject.getString("nombre"));
                dto.setApellido(jsonObject.getString("apellido"));
                //Log.d("ResultadoHttp","Json: " + dto.toString());
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            LogInActivity actividad = (LogInActivity) vista.getActividad();
            Intent i = new Intent(vista.getActividad(), MenuPrincipalActivity.class);
            i.putExtra("id",dto.getId());
            i.putExtra("nombre",dto.getNombre());
            i.putExtra("apellido",dto.getApellido());

            actividad.iniciarActividad(i);
        } else {
            modelo.setMensajeError("Usuario O Contraseña Incorrecto");
        }
        vista.cargarDesdeModelo();
        return true;
    }
}
