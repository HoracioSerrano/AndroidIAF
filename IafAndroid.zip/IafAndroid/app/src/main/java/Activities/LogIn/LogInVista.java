package Activities.LogIn;

import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.iafandroid.R;

public class LogInVista {
    public Activity getActividad() {
        return actividad;
    }

    private Activity actividad;
    private LogInModelo modelo;
    private LogInControl control;
    private EditText edtUsuario;
    private EditText edtPassword;
    private TextView txvError;
    private Button btnIngresar;

    public LogInVista(Activity actividad, LogInModelo modelo) {
        this.actividad = actividad;
        this.modelo = modelo;
        setearReferenciasControles();
    }

    private void setearReferenciasControles(){
        this.edtUsuario = actividad.findViewById(R.id.edtUsuario);
        this.edtPassword = actividad.findViewById(R.id.edtPassword);
        this.txvError = actividad.findViewById(R.id.txvError);
        this.btnIngresar = actividad.findViewById(R.id.btnIngresar);
    }

    public void cargarDesdeVista(){
        modelo.setUsuario(edtUsuario.getText().toString());
        modelo.setPassword(edtPassword.getText().toString());
        modelo.setMensajeError(txvError.getText().toString());
    }

    public void cargarDesdeModelo(){
        edtUsuario.setText(modelo.getUsuario());
        edtPassword.setText(modelo.getPassword());
        txvError.setText(modelo.getMensajeError());
    }

    public void setControl(LogInControl control) {
        this.control = control;
        setearControladores();
    }

    private void setearControladores(){
        this.btnIngresar.setOnClickListener(this.control);
    }

}
