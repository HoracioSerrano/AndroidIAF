package Utilitarios;

import android.net.Uri;
import android.util.Log;

import java.io.IOException;

public class HiloConsultaPost extends Thread{

    public String jsonDatos;

    @Override
    public void run(){
        Log.d("ResultadoHttp","Epieza Run " +jsonDatos);
        String url = "http://10.0.2.2:5069/LogIn";
        /*HttpConnection con = new HttpConnection();
        RespuestaHttp res = con.ejecutarPost(url,jsonDatos);*/

        String cadena = "";
/*
        HttpManager man= new HttpManager(url);
        try {
            cadena = man.getStrDataByGET();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
*/

        Uri.Builder params = new Uri.Builder();
        params.appendQueryParameter("Usuario","hserrano");
        params.appendQueryParameter("Password", "3184");

        HttpManager man= new HttpManager(url);
        try {
            cadena = man.getStrDataByPOST(params);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        Log.d("ResultadoHttp","Termina Run: " + cadena);
    }
}
