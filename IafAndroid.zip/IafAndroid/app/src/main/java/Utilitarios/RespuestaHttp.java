package Utilitarios;

import java.util.Objects;

public class RespuestaHttp {
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    private int codigo;

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    private String cuerpo;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RespuestaHttp that = (RespuestaHttp) o;
        return codigo == that.codigo && Objects.equals(cuerpo, that.cuerpo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, cuerpo);
    }

    @Override
    public String toString() {
        return "RespuestaHttp{" +
                "codigo=" + codigo +
                ", cuerpo='" + cuerpo + '\'' +
                '}';
    }
}
