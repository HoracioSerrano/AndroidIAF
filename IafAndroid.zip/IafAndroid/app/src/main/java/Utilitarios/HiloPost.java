package Utilitarios;

import android.net.Uri;

import java.io.IOException;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class HiloPost extends Thread{
    public int getValorArg() {
        return valorArg;
    }

    public void setValorArg(int valorArg) {
        this.valorArg = valorArg;
    }

    int valorArg;
    String url;
    Uri.Builder params;
    Handler handler;


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Uri.Builder getParams() {
        return params;
    }

    public void setParams(Uri.Builder params) {
        this.params = params;
    }

    public HiloPost(Handler handler, String url, Uri.Builder params){
        this.handler = handler;
        this.url = url;
        this.params = params;
    }

    @Override
    public void run(){
        String cadena;
        HttpManager man= new HttpManager(url);
        try {
            cadena = man.getStrDataByPOST(params);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Message men = new Message();
        men.arg1 = valorArg;
        men.obj = cadena;
        handler.sendMessage(men);

        Log.d("ResultadoHttp","Termina Run: " + cadena);
    }

}
