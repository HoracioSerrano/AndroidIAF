package Utilitarios;

public class dtoLogIn {
    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellid) {
        Apellido = apellid;
    }

    String Id;
    String Nombre;
    String Apellido;

    @Override
    public String toString() {
        return "dtoLogIn{" +
                "Id='" + Id + '\'' +
                ", Nombre='" + Nombre + '\'' +
                ", Apellid='" + Apellido + '\'' +
                '}';
    }
}
